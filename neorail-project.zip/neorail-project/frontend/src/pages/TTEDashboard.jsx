import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllTrains, getTrainById } from "../services/api";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

export default function TTEDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [trains, setTrains] = useState([]);
  const [selectedTrain, setSelectedTrain] = useState(null);
  const [trainDetail, setTrainDetail] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionMsg, setActionMsg] = useState("");
  const [actionLoading, setActionLoading] = useState(null);

  useEffect(() => {
    if (!user || user.role !== "tte") {
      navigate("/");
      return;
    }
    getAllTrains().then(r => setTrains(r.data)).catch(() => {});
  }, [user]);

  const selectTrain = async (train) => {
    setSelectedTrain(train);
    setActionMsg("");
    setLoading(true);
    try {
      const res = await getTrainById(train._id);
      setTrainDetail(res.data);
    } catch { }
    finally { setLoading(false); }
  };

  const refreshTrain = async () => {
    if (!selectedTrain) return;
    const res = await getTrainById(selectedTrain._id);
    setTrainDetail(res.data);
  };

  const markNotBoarded = async (seat_number) => {
    setActionLoading(`nb-${seat_number}`);
    setActionMsg("");
    try {
      const res = await api.post("/tickets/not-boarded", {
        train_id: trainDetail._id,
        seat_number
      });
      setActionMsg({ type: "success", text: res.data.message });
      await refreshTrain();
    } catch (err) {
      setActionMsg({ type: "error", text: err.response?.data?.error || "Action failed" });
    } finally {
      setActionLoading(null);
    }
  };

  const openSeat = async (seat_number) => {
    setActionLoading(`open-${seat_number}`);
    setActionMsg("");
    try {
      const res = await api.post("/tickets/open-seat", {
        train_id: trainDetail._id,
        seat_number
      });
      setActionMsg({ type: "success", text: res.data.message });
      await refreshTrain();
    } catch (err) {
      setActionMsg({ type: "error", text: err.response?.data?.error || "Action failed" });
    } finally {
      setActionLoading(null);
    }
  };

  if (!user || user.role !== "tte") return null;

  const seatStats = trainDetail ? {
    available: trainDetail.seats.filter(s => s.status === "available" || s.status === "open").length,
    booked: trainDetail.seats.filter(s => s.status === "booked").length,
    notBoarded: trainDetail.seats.filter(s => s.status === "not_boarded").length
  } : null;

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-6xl mx-auto px-4 py-10">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="text-xs font-orbitron tracking-widest mb-1" style={{ color: "rgba(123,47,255,0.8)" }}>
              TRAVELLING TICKET EXAMINER
            </div>
            <h1 className="font-orbitron font-black text-3xl" style={{ color: "#7b2fff", textShadow: "0 0 20px rgba(123,47,255,0.5)" }}>
              TTE DASHBOARD
            </h1>
          </div>
          <div className="glass-card px-4 py-2 text-xs font-orbitron" style={{ borderColor: "rgba(123,47,255,0.3)", color: "#7b2fff" }}>
            ⬡ TTE ACCESS
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Train List */}
          <div className="lg:col-span-1">
            <div className="text-xs font-orbitron tracking-widest mb-3" style={{ color: "rgba(123,47,255,0.7)" }}>
              SELECT TRAIN
            </div>
            <div className="space-y-2">
              {trains.map(train => {
                const avail = train.seats?.filter(s => s.status === "available" || s.status === "open").length || 0;
                const isSelected = selectedTrain?._id === train._id;
                return (
                  <button
                    key={train._id}
                    onClick={() => selectTrain(train)}
                    className="glass-card w-full p-4 text-left transition-all duration-200"
                    style={{
                      borderColor: isSelected ? "rgba(123,47,255,0.6)" : "rgba(123,47,255,0.1)",
                      background: isSelected ? "rgba(123,47,255,0.1)" : "",
                      boxShadow: isSelected ? "0 0 16px rgba(123,47,255,0.2)" : ""
                    }}
                  >
                    <p className="text-xs font-orbitron text-slate-500">#{train.train_number}</p>
                    <p className="font-semibold text-slate-200 text-sm mt-0.5">{train.train_name}</p>
                    <p className="text-xs text-slate-400 mt-1">{train.from_station} → {train.to_station}</p>
                    <div className="flex gap-3 mt-2 text-xs font-orbitron">
                      <span style={{ color: "#00f5ff" }}>{avail} FREE</span>
                      <span style={{ color: "#ff2d78" }}>{(train.total_seats || 0) - avail} TAKEN</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Seat Management Panel */}
          <div className="lg:col-span-2">
            {!selectedTrain && (
              <div className="glass-card p-12 text-center h-full flex flex-col items-center justify-center" style={{ borderColor: "rgba(123,47,255,0.15)" }}>
                <p className="font-orbitron text-xs tracking-widest text-slate-500">SELECT A TRAIN TO MANAGE SEATS</p>
              </div>
            )}

            {selectedTrain && loading && (
              <div className="glass-card p-12 text-center">
                <div className="inline-block w-10 h-10 rounded-full border-2 animate-spin" style={{ borderColor: "#7b2fff", borderTopColor: "transparent" }} />
              </div>
            )}

            {selectedTrain && !loading && trainDetail && (
              <div className="glass-card p-6" style={{ borderColor: "rgba(123,47,255,0.2)" }}>
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h2 className="font-orbitron font-bold text-lg" style={{ color: "#7b2fff" }}>{trainDetail.train_name}</h2>
                    <p className="text-sm text-slate-400">{trainDetail.from_station} → {trainDetail.to_station}</p>
                  </div>
                  <button onClick={refreshTrain} className="btn-cyber btn-cyber-purple text-xs">↻ REFRESH</button>
                </div>

                {/* Stats bar */}
                <div className="grid grid-cols-3 gap-3 mb-5">
                  {[
                    { label: "AVAILABLE", value: seatStats.available, color: "#00f5ff" },
                    { label: "BOOKED", value: seatStats.booked, color: "#ff2d78" },
                    { label: "NOT BOARDED", value: seatStats.notBoarded, color: "#ffe600" }
                  ].map(s => (
                    <div key={s.label} className="rounded p-3 text-center" style={{ background: `${s.color}10`, border: `1px solid ${s.color}30` }}>
                      <div className="font-orbitron font-bold text-xl" style={{ color: s.color }}>{s.value}</div>
                      <div className="text-xs text-slate-500 font-orbitron mt-0.5">{s.label}</div>
                    </div>
                  ))}
                </div>

                {/* Action message */}
                {actionMsg && (
                  <div className="mb-4 p-3 rounded text-sm" style={{
                    background: actionMsg.type === "success" ? "rgba(0,245,255,0.08)" : "rgba(255,45,120,0.08)",
                    border: `1px solid ${actionMsg.type === "success" ? "rgba(0,245,255,0.3)" : "rgba(255,45,120,0.3)"}`,
                    color: actionMsg.type === "success" ? "#00f5ff" : "#ff2d78"
                  }}>
                    {actionMsg.text}
                  </div>
                )}

                {/* Legend */}
                <div className="flex flex-wrap gap-3 mb-4 text-xs font-orbitron">
                  {[
                    { cls: "seat-available", label: "AVAILABLE" },
                    { cls: "seat-open", label: "OPEN" },
                    { cls: "seat-booked", label: "BOOKED" },
                    { cls: "seat-not_boarded", label: "NOT BOARDED" }
                  ].map(l => (
                    <div key={l.label} className="flex items-center gap-1.5">
                      <div className={`w-4 h-4 rounded ${l.cls}`} />
                      <span className="text-slate-400 tracking-wider">{l.label}</span>
                    </div>
                  ))}
                </div>

                {/* Seat grid with TTE actions */}
                <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
                  {trainDetail.seats.map(seat => (
                    <div
                      key={seat.seat_number}
                      className="flex items-center justify-between rounded px-4 py-2.5"
                      style={{
                        background: seat.status === "booked" ? "rgba(255,45,120,0.06)" :
                          seat.status === "not_boarded" ? "rgba(255,230,0,0.06)" :
                            seat.status === "open" ? "rgba(0,255,120,0.06)" :
                              "rgba(0,245,255,0.05)",
                        border: `1px solid ${seat.status === "booked" ? "rgba(255,45,120,0.2)" :
                          seat.status === "not_boarded" ? "rgba(255,230,0,0.2)" :
                            seat.status === "open" ? "rgba(0,255,120,0.2)" :
                              "rgba(0,245,255,0.15)"}`
                      }}
                    >
                      <div className="flex items-center gap-4">
                        <span className="font-orbitron font-bold text-sm w-10" style={{ color: "#e2e8f0" }}>
                          #{seat.seat_number}
                        </span>
                        <span className="text-xs font-orbitron tracking-wider" style={{
                          color: seat.status === "booked" ? "#ff2d78" :
                            seat.status === "not_boarded" ? "#ffe600" :
                              seat.status === "open" ? "#00ff78" : "#00f5ff"
                        }}>
                          {seat.status.replace("_", " ").toUpperCase()}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        {seat.status === "booked" && (
                          <button
                            onClick={() => markNotBoarded(seat.seat_number)}
                            disabled={actionLoading === `nb-${seat.seat_number}`}
                            className="text-xs font-orbitron px-3 py-1 rounded transition-all"
                            style={{
                              background: "rgba(255,230,0,0.1)",
                              border: "1px solid rgba(255,230,0,0.35)",
                              color: "#ffe600",
                              opacity: actionLoading === `nb-${seat.seat_number}` ? 0.5 : 1
                            }}
                          >
                            {actionLoading === `nb-${seat.seat_number}` ? "..." : "NOT BOARDED"}
                          </button>
                        )}
                        {seat.status === "not_boarded" && (
                          <button
                            onClick={() => openSeat(seat.seat_number)}
                            disabled={actionLoading === `open-${seat.seat_number}`}
                            className="text-xs font-orbitron px-3 py-1 rounded transition-all"
                            style={{
                              background: "rgba(0,255,120,0.1)",
                              border: "1px solid rgba(0,255,120,0.35)",
                              color: "#00ff78",
                              opacity: actionLoading === `open-${seat.seat_number}` ? 0.5 : 1
                            }}
                          >
                            {actionLoading === `open-${seat.seat_number}` ? "..." : "OPEN SEAT"}
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-slate-600 font-orbitron mt-4 tracking-wider">
                  TIP: Mark a booked seat as "NOT BOARDED" to notify a waiting passenger. Use "OPEN SEAT" to make it available for all.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
