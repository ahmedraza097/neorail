import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getTrainById, bookTicket } from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function SeatMap() {
  const { id } = useParams();
  const { user, openAuthModal } = useAuth();
  const navigate = useNavigate();

  const [train, setTrain] = useState(null);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  const fetchTrain = async () => {
    try {
      const res = await getTrainById(id);
      setTrain(res.data);
    } catch {
      setError("Failed to load train data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!user) {
      openAuthModal("login");
    }
    fetchTrain();
  }, [id]);

  const handleBook = async () => {
    if (!user) {
      openAuthModal("login");
      return;
    }
    setBooking(true);
    setError("");
    try {
      const res = await bookTicket(user._id, train._id);
      setResult(res.data);
      fetchTrain();
    } catch (err) {
      setError(err.response?.data?.error || "Booking failed.");
    } finally {
      setBooking(false);
    }
  };

  const availableCount = train?.seats?.filter(
    (s) => s.status === "available" || s.status === "open"
  ).length ?? 0;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <div
            className="inline-block w-14 h-14 rounded-full border-2 animate-spin mb-4"
            style={{ borderColor: "#00f5ff", borderTopColor: "transparent" }}
          />
          <p className="font-orbitron text-xs tracking-widest" style={{ color: "rgba(0,245,255,0.6)" }}>
            LOADING SEAT MAP...
          </p>
        </div>
      </div>
    );
  }

  if (error && !train) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="glass-card p-8 text-center" style={{ borderColor: "rgba(255,45,120,0.3)" }}>
          <p style={{ color: "#ff2d78" }}>{error}</p>
          <button onClick={() => navigate("/trains")} className="btn-cyber mt-4 text-xs">
            BACK TO TRAINS
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <button
          onClick={() => navigate("/trains")}
          className="text-xs font-orbitron tracking-wider mb-8 flex items-center gap-2 transition-colors"
          style={{ color: "rgba(0,245,255,0.6)" }}
          onMouseEnter={(e) => (e.currentTarget.style.color = "#00f5ff")}
          onMouseLeave={(e) => (e.currentTarget.style.color = "rgba(0,245,255,0.6)")}
        >
          ← BACK TO TRAINS
        </button>

        <div className="glass-card p-6 mb-8 glow-border-cyan scanline">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <p className="text-xs font-orbitron text-slate-500 tracking-wider mb-1">
                TRAIN #{train?.train_number}
              </p>
              <h1 className="font-orbitron font-black text-2xl" style={{ color: "#00f5ff" }}>
                {train?.train_name}
              </h1>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-sm text-slate-300 font-semibold">
                  {train?.from_station}
                </span>
                <span style={{ color: "rgba(0,245,255,0.5)" }}>→</span>
                <span className="text-sm text-slate-300 font-semibold">
                  {train?.to_station}
                </span>
              </div>
              <div className="flex gap-4 mt-1">
                <span className="text-xs font-mono" style={{ color: "rgba(0,245,255,0.6)" }}>
                  DEP: {train?.departure_time}
                </span>
                <span className="text-xs font-mono" style={{ color: "rgba(123,47,255,0.7)" }}>
                  ARR: {train?.arrival_time}
                </span>
              </div>
            </div>
            <div className="text-center">
              <div
                className="font-orbitron font-black text-4xl"
                style={{
                  color: availableCount > 0 ? "#00f5ff" : "#ff2d78",
                  textShadow: `0 0 20px ${availableCount > 0 ? "rgba(0,245,255,0.5)" : "rgba(255,45,120,0.5)"}`
                }}
              >
                {availableCount}
              </div>
              <div className="text-xs text-slate-400 font-orbitron tracking-wider">
                SEATS AVAILABLE
              </div>
            </div>
          </div>
        </div>

        {result && (
          <div
            className="glass-card p-5 mb-6"
            style={{
              borderColor:
                result.ticket?.status === "confirmed"
                  ? "rgba(0,245,255,0.4)"
                  : "rgba(255,230,0,0.4)"
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-lg flex-shrink-0"
                style={{
                  background:
                    result.ticket?.status === "confirmed"
                      ? "rgba(0,245,255,0.15)"
                      : "rgba(255,230,0,0.15)"
                }}
              >
                {result.ticket?.status === "confirmed" ? "✓" : "⏳"}
              </div>
              <div>
                <p
                  className="font-orbitron font-bold text-sm"
                  style={{
                    color:
                      result.ticket?.status === "confirmed" ? "#00f5ff" : "#ffe600"
                  }}
                >
                  {result.ticket?.status === "confirmed"
                    ? `BOOKED — SEAT #${result.ticket.seat_number}`
                    : "ADDED TO WAITING LIST"}
                </p>
                <p className="text-xs text-slate-400 mt-0.5">
                  {result.ticket?.status === "confirmed"
                    ? "Your seat is confirmed. Check your dashboard."
                    : "You'll be notified when a seat becomes available."}
                </p>
              </div>
              <button
                onClick={() => navigate("/dashboard")}
                className="btn-cyber text-xs ml-auto flex-shrink-0"
              >
                VIEW TICKETS
              </button>
            </div>
          </div>
        )}

        {error && (
          <div
            className="glass-card p-4 mb-6"
            style={{ borderColor: "rgba(255,45,120,0.3)" }}
          >
            <p className="text-sm" style={{ color: "#ff2d78" }}>
              {error}
            </p>
          </div>
        )}

        <div className="glass-card p-6 mb-6">
          <h2 className="font-orbitron text-xs tracking-widest mb-6" style={{ color: "rgba(0,245,255,0.7)" }}>
            SEAT MAP — COACH LAYOUT
          </h2>

          <div className="flex gap-4 flex-wrap mb-6 text-xs font-orbitron">
            {[
              { cls: "seat-available", label: "AVAILABLE" },
              { cls: "seat-open", label: "OPEN" },
              { cls: "seat-booked", label: "BOOKED" },
              { cls: "seat-not_boarded", label: "NOT BOARDED" }
            ].map((l) => (
              <div key={l.label} className="flex items-center gap-1.5">
                <div className={`w-5 h-5 rounded ${l.cls} flex items-center justify-center text-xs`} />
                <span className="text-slate-400 tracking-wider">{l.label}</span>
              </div>
            ))}
          </div>

          <div className="grid gap-2" style={{ gridTemplateColumns: "repeat(auto-fill, minmax(52px, 1fr))" }}>
            {train?.seats?.map((seat) => (
              <div
                key={seat.seat_number}
                className={`seat-${seat.status} rounded flex flex-col items-center justify-center py-2 text-xs font-orbitron`}
              >
                <span className="text-xs">{seat.seat_number}</span>
                <span className="text-xs opacity-60 mt-0.5">
                  {seat.status === "available" ? "●" : seat.status === "booked" ? "✗" : seat.status === "open" ? "◉" : "◌"}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-card p-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div>
              <p className="font-semibold text-slate-200">
                {availableCount > 0
                  ? "Ready to book your seat?"
                  : "No seats available — join the waitlist"}
              </p>
              <p className="text-sm text-slate-400 mt-0.5">
                {availableCount > 0
                  ? "The system will auto-assign the next available seat."
                  : "You'll be notified when a seat becomes available."}
              </p>
            </div>
            <button
              onClick={handleBook}
              disabled={booking}
              className={`btn-cyber ${availableCount === 0 ? "btn-cyber-purple" : ""} py-3 px-8 text-sm flex items-center gap-2 flex-shrink-0`}
            >
              {booking ? (
                <span className="inline-block w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
              ) : null}
              {availableCount > 0 ? "BOOK TICKET" : "JOIN WAITLIST"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
