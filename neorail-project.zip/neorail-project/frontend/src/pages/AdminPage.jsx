import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getAllTrains, getUserTickets } from "../services/api";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

export default function AdminPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [trains, setTrains] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [addForm, setAddForm] = useState({
    train_name: "", train_number: "", from_station: "",
    to_station: "", departure_time: "", arrival_time: "", total_seats: ""
  });
  const [addMsg, setAddMsg] = useState("");
  const [addLoading, setAddLoading] = useState(false);
  const [ticketFilter, setTicketFilter] = useState("all");

  useEffect(() => {
    if (!user || user.role !== "admin") {
      navigate("/");
      return;
    }
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      const [trainRes, ticketRes] = await Promise.all([
        getAllTrains(),
        api.get("/tickets/all")
      ]);
      setTrains(trainRes.data);
      setTickets(ticketRes.data);
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddTrain = async (e) => {
    e.preventDefault();
    setAddLoading(true);
    setAddMsg("");
    try {
      await api.post("/trains/add", {
        ...addForm,
        total_seats: Number(addForm.total_seats)
      });
      setAddMsg("success");
      setAddForm({ train_name: "", train_number: "", from_station: "", to_station: "", departure_time: "", arrival_time: "", total_seats: "" });
      fetchData();
    } catch (err) {
      setAddMsg("error: " + (err.response?.data?.error || "Failed"));
    } finally {
      setAddLoading(false);
    }
  };

  const stats = {
    trains: trains.length,
    totalSeats: trains.reduce((a, t) => a + (t.total_seats || 0), 0),
    booked: tickets.filter(t => t.status === "confirmed").length,
    waiting: tickets.filter(t => t.status === "waiting").length,
    notified: tickets.filter(t => t.status === "notified").length,
    totalTickets: tickets.length
  };

  const filteredTickets = ticketFilter === "all"
    ? tickets
    : tickets.filter(t => t.status === ticketFilter);

  if (!user || user.role !== "admin") return null;

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-7xl mx-auto px-4 py-10">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="text-xs font-orbitron tracking-widest mb-1" style={{ color: "rgba(255,45,120,0.8)" }}>
              ADMIN CONTROL PANEL
            </div>
            <h1 className="font-orbitron font-black text-3xl" style={{ color: "#ff2d78", textShadow: "0 0 20px rgba(255,45,120,0.5)" }}>
              SYSTEM ADMIN
            </h1>
          </div>
          <div className="glass-card px-4 py-2 text-xs font-orbitron" style={{ borderColor: "rgba(255,45,120,0.3)", color: "#ff2d78" }}>
            ⬡ ADMIN ACCESS
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
          {[
            { label: "TRAINS", value: stats.trains, color: "#00f5ff" },
            { label: "TOTAL SEATS", value: stats.totalSeats, color: "#00f5ff" },
            { label: "TOTAL TICKETS", value: stats.totalTickets, color: "#7b2fff" },
            { label: "CONFIRMED", value: stats.booked, color: "#00f5ff" },
            { label: "WAITING", value: stats.waiting, color: "#ffe600" },
            { label: "NOTIFIED", value: stats.notified, color: "#7b2fff" }
          ].map(s => (
            <div key={s.label} className="glass-card p-4 text-center" style={{ borderColor: `${s.color}30` }}>
              <div className="font-orbitron font-black text-2xl" style={{ color: s.color }}>{s.value}</div>
              <div className="text-xs font-orbitron tracking-widest mt-1 text-slate-500">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 flex-wrap">
          {[
            { key: "overview", label: "TRAINS OVERVIEW" },
            { key: "tickets", label: "ALL BOOKINGS" },
            { key: "add", label: "+ ADD TRAIN" }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className="btn-cyber text-xs"
              style={{
                borderColor: activeTab === tab.key ? "#ff2d78" : "rgba(0,245,255,0.3)",
                color: activeTab === tab.key ? "#ff2d78" : "#00f5ff",
                background: activeTab === tab.key ? "rgba(255,45,120,0.1)" : ""
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab: Trains Overview */}
        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
            {trains.map(train => {
              const avail = train.seats?.filter(s => s.status === "available" || s.status === "open").length || 0;
              const booked = train.seats?.filter(s => s.status === "booked").length || 0;
              const waiting = tickets.filter(t => t.train_id === train._id && t.status === "waiting").length;
              return (
                <div key={train._id} className="glass-card p-5" style={{ borderColor: "rgba(255,45,120,0.15)" }}>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="text-xs font-orbitron text-slate-500">#{train.train_number}</p>
                      <h3 className="font-orbitron font-bold text-base text-slate-200 mt-0.5">{train.train_name}</h3>
                    </div>
                  </div>
                  <p className="text-xs text-slate-400 mb-3">{train.from_station} → {train.to_station}</p>
                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="rounded p-2" style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.2)" }}>
                      <div className="font-orbitron font-bold text-base" style={{ color: "#00f5ff" }}>{avail}</div>
                      <div className="text-slate-500 mt-0.5">FREE</div>
                    </div>
                    <div className="rounded p-2" style={{ background: "rgba(255,45,120,0.08)", border: "1px solid rgba(255,45,120,0.2)" }}>
                      <div className="font-orbitron font-bold text-base" style={{ color: "#ff2d78" }}>{booked}</div>
                      <div className="text-slate-500 mt-0.5">BOOKED</div>
                    </div>
                    <div className="rounded p-2" style={{ background: "rgba(255,230,0,0.08)", border: "1px solid rgba(255,230,0,0.2)" }}>
                      <div className="font-orbitron font-bold text-base" style={{ color: "#ffe600" }}>{waiting}</div>
                      <div className="text-slate-500 mt-0.5">WAIT</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Tab: All Bookings */}
        {activeTab === "tickets" && (
          <div>
            <div className="flex gap-2 mb-4 flex-wrap">
              {["all", "confirmed", "waiting", "notified"].map(f => (
                <button
                  key={f}
                  onClick={() => setTicketFilter(f)}
                  className="text-xs font-orbitron px-3 py-1 rounded transition-all"
                  style={{
                    background: ticketFilter === f ? "rgba(255,45,120,0.15)" : "rgba(255,255,255,0.04)",
                    border: `1px solid ${ticketFilter === f ? "rgba(255,45,120,0.5)" : "rgba(255,255,255,0.1)"}`,
                    color: ticketFilter === f ? "#ff2d78" : "#94a3b8"
                  }}
                >
                  {f.toUpperCase()} ({f === "all" ? tickets.length : tickets.filter(t => t.status === f).length})
                </button>
              ))}
            </div>
            <div className="glass-card overflow-hidden" style={{ borderColor: "rgba(255,45,120,0.15)" }}>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ borderBottom: "1px solid rgba(255,45,120,0.15)", background: "rgba(255,45,120,0.05)" }}>
                      {["PASSENGER", "EMAIL", "TRAIN", "ROUTE", "SEAT", "STATUS"].map(h => (
                        <th key={h} className="text-left px-4 py-3 text-xs font-orbitron tracking-widest text-slate-500">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredTickets.length === 0 && (
                      <tr><td colSpan={6} className="text-center py-8 text-slate-500 text-xs font-orbitron">NO TICKETS FOUND</td></tr>
                    )}
                    {filteredTickets.map((t, i) => (
                      <tr
                        key={t._id}
                        style={{ borderBottom: "1px solid rgba(255,255,255,0.04)", background: i % 2 === 0 ? "transparent" : "rgba(255,255,255,0.02)" }}
                      >
                        <td className="px-4 py-3 font-medium text-slate-200">{t.user?.name || "—"}</td>
                        <td className="px-4 py-3 text-slate-400 text-xs">{t.user?.email || "—"}</td>
                        <td className="px-4 py-3 text-slate-300">{t.train?.train_name || "—"}</td>
                        <td className="px-4 py-3 text-slate-400 text-xs">{t.train ? `${t.train.from_station} → ${t.train.to_station}` : "—"}</td>
                        <td className="px-4 py-3 font-orbitron text-xs" style={{ color: "#00f5ff" }}>
                          {t.seat_number ? `#${t.seat_number}` : "—"}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`tag-${t.status}`}>{t.status.toUpperCase()}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab: Add Train */}
        {activeTab === "add" && (
          <div className="max-w-xl">
            <div className="glass-card p-7" style={{ borderColor: "rgba(255,45,120,0.2)" }}>
              <h2 className="font-orbitron font-bold text-sm mb-6" style={{ color: "#ff2d78" }}>ADD NEW TRAIN</h2>
              <form onSubmit={handleAddTrain} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Field label="TRAIN NAME" name="train_name" form={addForm} set={setAddForm} placeholder="Rajdhani Express" required />
                  <Field label="TRAIN NUMBER" name="train_number" form={addForm} set={setAddForm} placeholder="12301" required />
                  <Field label="FROM STATION" name="from_station" form={addForm} set={setAddForm} placeholder="Mumbai Central" required />
                  <Field label="TO STATION" name="to_station" form={addForm} set={setAddForm} placeholder="New Delhi" required />
                  <Field label="DEPARTURE TIME" name="departure_time" form={addForm} set={setAddForm} placeholder="16:35" />
                  <Field label="ARRIVAL TIME" name="arrival_time" form={addForm} set={setAddForm} placeholder="08:35" />
                </div>
                <Field label="TOTAL SEATS" name="total_seats" form={addForm} set={setAddForm} placeholder="20" type="number" required />
                {addMsg === "success" && (
                  <div className="text-sm p-3 rounded" style={{ background: "rgba(0,245,255,0.08)", border: "1px solid rgba(0,245,255,0.3)", color: "#00f5ff" }}>
                    Train added successfully!
                  </div>
                )}
                {addMsg.startsWith("error") && (
                  <div className="text-sm p-3 rounded" style={{ background: "rgba(255,45,120,0.08)", border: "1px solid rgba(255,45,120,0.3)", color: "#ff2d78" }}>
                    {addMsg}
                  </div>
                )}
                <button type="submit" disabled={addLoading} className="btn-cyber btn-cyber-pink w-full py-3 text-sm">
                  {addLoading ? "ADDING..." : "ADD TRAIN →"}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, name, form, set, placeholder, type = "text", required }) {
  return (
    <div>
      <label className="block text-xs font-orbitron text-slate-500 mb-1 tracking-wider">{label}</label>
      <input
        className="input-cyber"
        type={type}
        placeholder={placeholder}
        value={form[name]}
        onChange={e => set(f => ({ ...f, [name]: e.target.value }))}
        required={required}
      />
    </div>
  );
}
