import React, { useEffect, useState } from "react";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { getAllTrains, searchTrains } from "../services/api";
import { useAuth } from "../context/AuthContext";

export default function Trains() {
  const [trains, setTrains] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchParams] = useSearchParams();
  const { openAuthModal, user } = useAuth();
  const navigate = useNavigate();

  const from = searchParams.get("from") || "";
  const to = searchParams.get("to") || "";

  useEffect(() => {
    const fetchTrains = async () => {
      setLoading(true);
      try {
        const res = from || to ? await searchTrains(from, to) : await getAllTrains();
        setTrains(res.data);
      } catch {
        setError("Failed to load trains. Backend may be unavailable.");
      } finally {
        setLoading(false);
      }
    };
    fetchTrains();
  }, [from, to]);

  const handleSelect = (train) => {
    if (!user) {
      openAuthModal("login");
      return;
    }
    navigate(`/seats/${train._id}`);
  };

  const availableCount = (train) =>
    train.seats?.filter((s) => s.status === "available" || s.status === "open").length || 0;

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-orbitron font-bold text-2xl" style={{ color: "#00f5ff" }}>
              AVAILABLE TRAINS
            </h1>
            {(from || to) && (
              <p className="text-slate-400 text-sm mt-1 font-rajdhani">
                {from && `FROM: ${from}`}
                {from && to && " → "}
                {to && `TO: ${to}`}
              </p>
            )}
          </div>
          <Link to="/" className="btn-cyber btn-cyber-purple text-xs">
            ← NEW SEARCH
          </Link>
        </div>

        {loading && (
          <div className="text-center py-20">
            <div
              className="inline-block w-12 h-12 rounded-full border-2 animate-spin mb-4"
              style={{ borderColor: "#00f5ff", borderTopColor: "transparent" }}
            />
            <p className="font-orbitron text-xs tracking-widest" style={{ color: "rgba(0,245,255,0.6)" }}>
              SCANNING NETWORK...
            </p>
          </div>
        )}

        {error && (
          <div
            className="glass-card p-6 text-center"
            style={{ borderColor: "rgba(255,45,120,0.3)" }}
          >
            <p style={{ color: "#ff2d78" }}>{error}</p>
          </div>
        )}

        {!loading && !error && trains.length === 0 && (
          <div className="glass-card p-12 text-center">
            <p className="font-orbitron text-sm tracking-widest text-slate-400">
              NO TRAINS FOUND
            </p>
            <p className="text-slate-500 mt-2 text-sm">
              Try different stations or{" "}
              <Link to="/" className="underline" style={{ color: "#00f5ff" }}>
                search again
              </Link>
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {trains.map((train) => {
            const avail = availableCount(train);
            const full = avail === 0;
            return (
              <div
                key={train._id}
                className="glass-card p-6 relative overflow-hidden group cursor-pointer transition-all duration-300"
                style={{ borderColor: full ? "rgba(255,45,120,0.2)" : "rgba(0,245,255,0.2)" }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = full
                    ? "rgba(255,45,120,0.5)"
                    : "rgba(0,245,255,0.5)";
                  e.currentTarget.style.transform = "translateY(-2px)";
                  e.currentTarget.style.boxShadow = full
                    ? "0 8px 32px rgba(255,45,120,0.15)"
                    : "0 8px 32px rgba(0,245,255,0.15)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = full
                    ? "rgba(255,45,120,0.2)"
                    : "rgba(0,245,255,0.2)";
                  e.currentTarget.style.transform = "translateY(0)";
                  e.currentTarget.style.boxShadow = "";
                }}
              >
                <div
                  className="absolute top-0 right-0 w-24 h-24 opacity-5 rounded-full"
                  style={{
                    background: full ? "#ff2d78" : "#00f5ff",
                    transform: "translate(30%, -30%)",
                    filter: "blur(20px)"
                  }}
                />

                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-xs font-orbitron text-slate-500 tracking-wider mb-1">
                      TRAIN #{train.train_number || "—"}
                    </p>
                    <h3
                      className="font-orbitron font-bold text-base leading-tight"
                      style={{ color: "#e2e8f0" }}
                    >
                      {train.train_name}
                    </h3>
                  </div>
                  <div
                    className="text-xs font-orbitron px-2 py-1 rounded"
                    style={{
                      background: full
                        ? "rgba(255,45,120,0.12)"
                        : avail <= 5
                        ? "rgba(255,230,0,0.12)"
                        : "rgba(0,245,255,0.1)",
                      border: `1px solid ${
                        full
                          ? "rgba(255,45,120,0.3)"
                          : avail <= 5
                          ? "rgba(255,230,0,0.3)"
                          : "rgba(0,245,255,0.3)"
                      }`,
                      color: full ? "#ff2d78" : avail <= 5 ? "#ffe600" : "#00f5ff"
                    }}
                  >
                    {full ? "FULL" : `${avail} LEFT`}
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <div className="flex-1">
                    <p className="text-xs text-slate-500 mb-0.5">FROM</p>
                    <p className="font-semibold text-sm text-slate-200 leading-tight">
                      {train.from_station || "—"}
                    </p>
                    <p className="text-xs font-mono" style={{ color: "rgba(0,245,255,0.6)" }}>
                      {train.departure_time || ""}
                    </p>
                  </div>
                  <div className="flex-shrink-0 flex flex-col items-center gap-1">
                    <div className="w-2 h-2 rounded-full" style={{ background: "#00f5ff" }} />
                    <div className="w-px h-8" style={{ background: "rgba(0,245,255,0.3)" }} />
                    <div className="w-2 h-2 rounded-full" style={{ background: "#7b2fff" }} />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="text-xs text-slate-500 mb-0.5">TO</p>
                    <p className="font-semibold text-sm text-slate-200 leading-tight">
                      {train.to_station || "—"}
                    </p>
                    <p className="text-xs font-mono" style={{ color: "rgba(123,47,255,0.8)" }}>
                      {train.arrival_time || ""}
                    </p>
                  </div>
                </div>

                <SeatBar seats={train.seats} />

                <button
                  onClick={() => handleSelect(train)}
                  className={`btn-cyber w-full mt-4 py-2.5 text-xs ${full ? "btn-cyber-purple" : ""}`}
                >
                  {full ? "JOIN WAITLIST" : "SELECT SEATS →"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function SeatBar({ seats }) {
  if (!seats?.length) return null;
  const avail = seats.filter((s) => s.status === "available" || s.status === "open").length;
  const pct = Math.round((avail / seats.length) * 100);

  return (
    <div>
      <div className="flex justify-between text-xs text-slate-500 mb-1">
        <span className="font-orbitron tracking-widest">CAPACITY</span>
        <span className="font-mono">
          {avail}/{seats.length}
        </span>
      </div>
      <div className="w-full h-1.5 rounded-full" style={{ background: "rgba(255,255,255,0.07)" }}>
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{
            width: `${pct}%`,
            background:
              pct > 50
                ? "linear-gradient(90deg, #00f5ff, #7b2fff)"
                : pct > 20
                ? "linear-gradient(90deg, #ffe600, #ff9500)"
                : "linear-gradient(90deg, #ff2d78, #ff9500)"
          }}
        />
      </div>
    </div>
  );
}
