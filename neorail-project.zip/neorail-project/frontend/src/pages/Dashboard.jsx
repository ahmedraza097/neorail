import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getUserTickets } from "../services/api";
import { useAuth } from "../context/AuthContext";
import TicketCard from "../components/TicketCard";

export default function Dashboard() {
  const { user, openAuthModal } = useAuth();
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      openAuthModal("login");
      return;
    }
    const fetch = async () => {
      try {
        const res = await getUserTickets(user._id);
        setTickets(res.data);
      } catch {
        setTickets([]);
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [user]);

  const filtered =
    filter === "all" ? tickets : tickets.filter((t) => t.status === filter);

  const counts = {
    all: tickets.length,
    confirmed: tickets.filter((t) => t.status === "confirmed").length,
    waiting: tickets.filter((t) => t.status === "waiting").length,
    notified: tickets.filter((t) => t.status === "notified").length
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="glass-card p-10 text-center max-w-sm">
          <p className="font-orbitron text-sm tracking-widest text-slate-400 mb-4">
            ACCESS RESTRICTED
          </p>
          <p className="text-slate-500 text-sm mb-6">
            Please log in to view your dashboard.
          </p>
          <button onClick={() => openAuthModal("login")} className="btn-cyber w-full">
            LOGIN
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <p className="text-xs font-orbitron text-slate-500 tracking-widest mb-1">
              PASSENGER PROFILE
            </p>
            <h1 className="font-orbitron font-black text-3xl" style={{ color: "#00f5ff" }}>
              {user.name?.toUpperCase()}
            </h1>
            <p className="text-slate-400 text-sm mt-1">{user.email}</p>
          </div>
          <Link to="/trains" className="btn-cyber text-xs">
            + BOOK NEW TICKET
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { key: "all", label: "TOTAL", color: "#00f5ff" },
            { key: "confirmed", label: "CONFIRMED", color: "#00f5ff" },
            { key: "waiting", label: "WAITING", color: "#ffe600" },
            { key: "notified", label: "NOTIFIED", color: "#7b2fff" }
          ].map((s) => (
            <button
              key={s.key}
              onClick={() => setFilter(s.key)}
              className="glass-card p-4 text-center transition-all duration-200"
              style={{
                borderColor:
                  filter === s.key ? s.color : "rgba(0,245,255,0.1)",
                boxShadow: filter === s.key ? `0 0 16px ${s.color}30` : "none"
              }}
            >
              <div
                className="font-orbitron font-black text-3xl"
                style={{ color: s.color }}
              >
                {counts[s.key]}
              </div>
              <div className="text-xs font-orbitron tracking-widest mt-1 text-slate-500">
                {s.label}
              </div>
            </button>
          ))}
        </div>

        <div
          className="text-xs font-orbitron tracking-[0.3em] mb-4"
          style={{ color: "rgba(0,245,255,0.5)" }}
        >
          MY JOURNEYS
        </div>

        {loading && (
          <div className="text-center py-16">
            <div
              className="inline-block w-10 h-10 rounded-full border-2 animate-spin mb-3"
              style={{ borderColor: "#00f5ff", borderTopColor: "transparent" }}
            />
            <p className="font-orbitron text-xs tracking-widest" style={{ color: "rgba(0,245,255,0.5)" }}>
              LOADING TICKETS...
            </p>
          </div>
        )}

        {!loading && filtered.length === 0 && (
          <div className="glass-card p-12 text-center">
            <p className="font-orbitron text-xs tracking-widest text-slate-500 mb-4">
              NO TICKETS FOUND
            </p>
            <Link to="/trains" className="btn-cyber text-xs">
              BOOK YOUR FIRST TICKET →
            </Link>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filtered.map((ticket) => (
            <TicketCard key={ticket._id} ticket={ticket} />
          ))}
        </div>
      </div>
    </div>
  );
}
