import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const STATIONS = [
  "Mumbai Central",
  "New Delhi",
  "Kolkata",
  "Chennai Central",
  "Bengaluru",
  "Hyderabad",
  "Bhopal",
  "Ahmedabad",
  "Pune",
  "Jaipur"
];

export default function Home() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    navigate(`/trains?${params.toString()}`);
  };

  return (
    <div className="min-h-screen relative z-10">
      <div className="max-w-7xl mx-auto px-4 pt-20 pb-10">
        <div className="text-center mb-16">
          <div
            className="inline-block font-orbitron text-xs tracking-[0.4em] mb-4 px-4 py-1 rounded-full"
            style={{
              background: "rgba(0,245,255,0.08)",
              border: "1px solid rgba(0,245,255,0.2)",
              color: "rgba(0,245,255,0.8)"
            }}
          >
            NEXT-GEN RAIL TRAVEL
          </div>

          <h1
            className="font-orbitron font-black text-5xl md:text-7xl leading-tight mb-6"
            style={{
              background: "linear-gradient(135deg, #00f5ff 0%, #7b2fff 50%, #ff2d78 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
              textShadow: "none"
            }}
          >
            BOOK YOUR
            <br />
            JOURNEY
          </h1>
          <p className="text-slate-400 text-lg max-w-xl mx-auto font-rajdhani font-medium">
            Experience the future of rail travel. Real-time seat availability, instant booking, zero friction.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <form
            onSubmit={handleSearch}
            className="glass-card glow-border-cyan p-8 scanline"
          >
            <h2
              className="font-orbitron text-sm tracking-[0.3em] mb-6"
              style={{ color: "rgba(0,245,255,0.7)" }}
            >
              SEARCH TRAINS
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-xs font-orbitron text-slate-500 mb-2 tracking-wider">
                  ORIGIN STATION
                </label>
                <select
                  className="input-cyber"
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                >
                  <option value="">— Select Station —</option>
                  {STATIONS.map((s) => (
                    <option key={s} value={s} style={{ background: "#0a0f2e" }}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-orbitron text-slate-500 mb-2 tracking-wider">
                  DESTINATION
                </label>
                <select
                  className="input-cyber"
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                >
                  <option value="">— Select Station —</option>
                  {STATIONS.map((s) => (
                    <option key={s} value={s} style={{ background: "#0a0f2e" }}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <button type="submit" className="btn-cyber w-full py-3 text-sm pulse-cyan">
              SCAN FOR TRAINS
            </button>
          </form>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-20 max-w-4xl mx-auto">
          {[
            {
              icon: "⚡",
              title: "Instant Booking",
              desc: "Seats confirmed in milliseconds with real-time availability checks."
            },
            {
              icon: "🎯",
              title: "Smart Waitlist",
              desc: "Auto-notified when seats open. Never miss your chance to board."
            },
            {
              icon: "🔐",
              title: "Secure Sessions",
              desc: "Your journey data is encrypted and private at every step."
            }
          ].map((f) => (
            <div key={f.title} className="glass-card p-6 text-center">
              <div className="text-4xl mb-4">{f.icon}</div>
              <h3 className="font-orbitron font-bold text-sm mb-2" style={{ color: "#00f5ff" }}>
                {f.title}
              </h3>
              <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
