import React from "react";

export default function TicketCard({ ticket }) {
  const { train, seat_number, status } = ticket;

  const statusTag = {
    confirmed: <span className="tag-confirmed">CONFIRMED</span>,
    waiting: <span className="tag-waiting">WAITING LIST</span>,
    notified: <span className="tag-notified">SEAT NOTIFIED</span>
  }[status] || <span className="tag-waiting">{status}</span>;

  return (
    <div
      className="glass-card p-5 relative overflow-hidden"
      style={{
        borderColor:
          status === "confirmed"
            ? "rgba(0,245,255,0.3)"
            : status === "notified"
            ? "rgba(123,47,255,0.3)"
            : "rgba(255,230,0,0.2)"
      }}
    >
      <div
        className="absolute top-0 left-0 w-1 h-full"
        style={{
          background:
            status === "confirmed"
              ? "linear-gradient(to bottom, #00f5ff, #7b2fff)"
              : status === "notified"
              ? "linear-gradient(to bottom, #7b2fff, #ff2d78)"
              : "linear-gradient(to bottom, #ffe600, #ff9500)"
        }}
      />

      <div className="pl-3">
        <div className="flex items-start justify-between mb-3">
          <div>
            <h3 className="font-orbitron font-bold text-base" style={{ color: "#00f5ff" }}>
              {train?.train_name || "Unknown Train"}
            </h3>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              #{train?.train_number || "—"}
            </p>
          </div>
          {statusTag}
        </div>

        <div className="grid grid-cols-2 gap-3 mt-3">
          <RoutePoint label="FROM" value={train?.from_station || "—"} />
          <RoutePoint label="TO" value={train?.to_station || "—"} />
          <InfoItem label="DEPARTS" value={train?.departure_time || "—"} />
          <InfoItem label="ARRIVES" value={train?.arrival_time || "—"} />
          {seat_number && <InfoItem label="SEAT NO." value={`#${seat_number}`} highlight />}
        </div>
      </div>
    </div>
  );
}

function RoutePoint({ label, value }) {
  return (
    <div>
      <p className="text-xs text-slate-500 font-orbitron tracking-widest mb-0.5">{label}</p>
      <p className="font-semibold text-slate-200 text-sm leading-tight">{value}</p>
    </div>
  );
}

function InfoItem({ label, value, highlight }) {
  return (
    <div>
      <p className="text-xs text-slate-500 font-orbitron tracking-widest mb-0.5">{label}</p>
      <p
        className={`font-semibold text-sm ${highlight ? "font-orbitron" : ""}`}
        style={{ color: highlight ? "#00f5ff" : "#e2e8f0" }}
      >
        {value}
      </p>
    </div>
  );
}
