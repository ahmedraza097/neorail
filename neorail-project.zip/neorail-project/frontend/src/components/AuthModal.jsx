import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { loginUser, registerUser } from "../services/api";

export default function AuthModal() {
  const { authModal, closeAuthModal, login, openAuthModal } = useAuth();
  const [mode, setMode] = useState(authModal || "login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  if (!authModal) return null;

  const handleChange = (e) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      if (mode === "login") {
        const res = await loginUser({ email: form.email, password: form.password });
        login(res.data.user);
        closeAuthModal();
      } else {
        await registerUser({ name: form.name, email: form.email, password: form.password });
        const res = await loginUser({ email: form.email, password: form.password });
        login(res.data.user);
        closeAuthModal();
      }
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data?.error || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const switchMode = (m) => {
    setMode(m);
    openAuthModal(m);
    setError("");
    setForm({ name: "", email: "", password: "" });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(5,5,16,0.85)", backdropFilter: "blur(8px)" }}
      onClick={closeAuthModal}
    >
      <div
        className="glass-card glow-border-purple w-full max-w-md p-8 relative scanline"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={closeAuthModal}
          className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors text-xl font-bold"
        >
          ×
        </button>

        <div className="mb-8 text-center">
          <h2
            className="font-orbitron font-black text-2xl mb-1"
            style={{ color: "#00f5ff", textShadow: "0 0 16px rgba(0,245,255,0.7)" }}
          >
            {mode === "login" ? "ACCESS SYSTEM" : "NEW IDENTITY"}
          </h2>
          <p className="text-slate-400 text-sm font-rajdhani">
            {mode === "login" ? "Enter your credentials to continue" : "Create your NeoRail account"}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === "register" && (
            <div>
              <label className="block text-xs font-orbitron text-slate-400 mb-1 tracking-wider">
                FULL NAME
              </label>
              <input
                className="input-cyber"
                name="name"
                placeholder="John Doe"
                value={form.name}
                onChange={handleChange}
                required
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-orbitron text-slate-400 mb-1 tracking-wider">
              EMAIL
            </label>
            <input
              className="input-cyber"
              name="email"
              type="email"
              placeholder="user@neorail.io"
              value={form.email}
              onChange={handleChange}
              required
            />
          </div>
          <div>
            <label className="block text-xs font-orbitron text-slate-400 mb-1 tracking-wider">
              PASSWORD
            </label>
            <input
              className="input-cyber"
              name="password"
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
              required
            />
          </div>

          {error && (
            <div
              className="text-sm p-3 rounded"
              style={{
                background: "rgba(255,45,120,0.1)",
                border: "1px solid rgba(255,45,120,0.3)",
                color: "#ff2d78"
              }}
            >
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="btn-cyber w-full py-3 mt-2 flex items-center justify-center gap-2 text-sm"
            style={{ opacity: loading ? 0.7 : 1 }}
          >
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
            ) : (
              mode === "login" ? "JACK IN" : "CREATE ACCOUNT"
            )}
          </button>
        </form>

        <div className="mt-6 text-center">
          <span className="text-slate-500 text-sm">
            {mode === "login" ? "No account? " : "Already registered? "}
          </span>
          <button
            onClick={() => switchMode(mode === "login" ? "register" : "login")}
            className="text-sm font-semibold transition-colors"
            style={{ color: "#7b2fff" }}
            onMouseEnter={(e) => (e.target.style.color = "#00f5ff")}
            onMouseLeave={(e) => (e.target.style.color = "#7b2fff")}
          >
            {mode === "login" ? "Register here" : "Login instead"}
          </button>
        </div>
      </div>
    </div>
  );
}
