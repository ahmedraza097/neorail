import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout, openAuthModal } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const roleColor = user?.role === "admin" ? "#ff2d78" : user?.role === "tte" ? "#7b2fff" : "#00f5ff";
  const roleLabel = user?.role === "admin" ? "ADMIN" : user?.role === "tte" ? "TTE" : null;

  return (
    <nav className="relative z-50 w-full">
      <div className="glass-card rounded-none border-x-0 border-t-0" style={{ borderBottom: "1px solid rgba(0,245,255,0.15)" }}>
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div
              className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0"
              style={{ background: "linear-gradient(135deg, #00f5ff, #7b2fff)", boxShadow: "0 0 16px rgba(0,245,255,0.5)" }}
            >
              <svg viewBox="0 0 24 24" fill="none" className="w-5 h-5" stroke="white" strokeWidth="2">
                <path d="M4 15l4-8 4 8 4-8 4 8" /><line x1="2" y1="19" x2="22" y2="19" />
              </svg>
            </div>
            <span className="font-orbitron font-black text-xl tracking-wider glitch" style={{ color: "#00f5ff", textShadow: "0 0 12px rgba(0,245,255,0.7)" }}>
              NEORAIL
            </span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <NavLink to="/">Home</NavLink>
            <NavLink to="/trains">Trains</NavLink>
            {user && user.role === "user" && <NavLink to="/dashboard">Dashboard</NavLink>}
            {user && user.role === "admin" && <NavLink to="/admin" color="#ff2d78">Admin Panel</NavLink>}
            {user && user.role === "tte" && <NavLink to="/tte" color="#7b2fff">TTE Panel</NavLink>}
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <div className="hidden md:flex items-center gap-2">
                  {roleLabel && (
                    <span
                      className="text-xs font-orbitron px-2 py-0.5 rounded"
                      style={{ background: `${roleColor}15`, border: `1px solid ${roleColor}40`, color: roleColor }}
                    >
                      {roleLabel}
                    </span>
                  )}
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-orbitron font-bold"
                    style={{ background: `linear-gradient(135deg, ${roleColor}30, rgba(123,47,255,0.3))`, border: `1px solid ${roleColor}50`, color: roleColor }}
                  >
                    {user.name?.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-sm text-slate-300 font-medium">{user.name}</span>
                </div>
                <button onClick={handleLogout} className="btn-cyber btn-cyber-pink text-xs">Logout</button>
              </>
            ) : (
              <>
                <button onClick={() => openAuthModal("login")} className="btn-cyber text-xs">Login</button>
                <button onClick={() => openAuthModal("register")} className="btn-cyber btn-cyber-purple text-xs">Register</button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({ to, children, color = "#e2e8f0" }) {
  return (
    <Link
      to={to}
      className="font-rajdhani font-semibold text-sm tracking-widest uppercase transition-all duration-200"
      style={{ color: "rgba(226,232,240,0.7)" }}
      onMouseEnter={e => { e.target.style.color = color; e.target.style.textShadow = `0 0 8px ${color}80`; }}
      onMouseLeave={e => { e.target.style.color = "rgba(226,232,240,0.7)"; e.target.style.textShadow = "none"; }}
    >
      {children}
    </Link>
  );
}
