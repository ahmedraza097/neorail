/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        orbitron: ["Orbitron", "sans-serif"],
        rajdhani: ["Rajdhani", "sans-serif"]
      },
      colors: {
        cyber: {
          bg: "#050510",
          card: "#0a0f2e",
          cyan: "#00f5ff",
          purple: "#7b2fff",
          pink: "#ff2d78",
          yellow: "#ffe600",
          border: "rgba(0,245,255,0.2)"
        }
      }
    }
  },
  plugins: []
};
