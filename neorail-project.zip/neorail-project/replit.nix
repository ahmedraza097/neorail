{pkgs}: {
  deps = [
    pkgs.mongodb
  ];
}
