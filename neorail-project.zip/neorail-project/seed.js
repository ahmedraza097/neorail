const mongoose = require("mongoose");
require("dotenv").config();

const Train = require("./models/Train");
const User = require("./models/User");

const sampleTrains = [
  {
    train_name: "Rajdhani Express",
    train_number: "12301",
    from_station: "Mumbai Central",
    to_station: "New Delhi",
    departure_time: "16:35",
    arrival_time: "08:35",
    total_seats: 20
  },
  {
    train_name: "Shatabdi Express",
    train_number: "12002",
    from_station: "New Delhi",
    to_station: "Bhopal",
    departure_time: "06:00",
    arrival_time: "14:00",
    total_seats: 18
  },
  {
    train_name: "Duronto Express",
    train_number: "12213",
    from_station: "Kolkata",
    to_station: "Mumbai Central",
    departure_time: "20:15",
    arrival_time: "11:45",
    total_seats: 24
  },
  {
    train_name: "Vande Bharat Express",
    train_number: "22435",
    from_station: "Chennai Central",
    to_station: "Bengaluru",
    departure_time: "06:00",
    arrival_time: "10:30",
    total_seats: 16
  },
  {
    train_name: "Garib Rath Express",
    train_number: "12216",
    from_station: "Bengaluru",
    to_station: "Hyderabad",
    departure_time: "22:30",
    arrival_time: "06:00",
    total_seats: 30
  }
];

const defaultUsers = [
  { name: "Admin", email: "admin@neorail.io", password: "admin123", role: "admin" },
  { name: "TTE Officer", email: "tte@neorail.io", password: "tte123", role: "tte" }
];

async function seed() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected");

    // Seed trains only if none exist
    const existingTrains = await Train.countDocuments();
    if (existingTrains === 0) {
      for (const t of sampleTrains) {
        const seats = [];
        for (let i = 1; i <= t.total_seats; i++) {
          seats.push({ seat_number: i, status: "available" });
        }
        await Train.create({ ...t, seats });
        console.log(`Added train: ${t.train_name}`);
      }
    } else {
      console.log(`Trains already seeded (${existingTrains}) — skipping.`);
    }

    // Seed default admin & TTE users if they don't exist
    for (const u of defaultUsers) {
      const exists = await User.findOne({ email: u.email });
      if (!exists) {
        await User.create(u);
        console.log(`Created ${u.role} account: ${u.email}`);
      }
    }

    console.log("Seeding complete!");
    process.exit(0);
  } catch (err) {
    console.error("Seed error:", err.message);
    process.exit(1);
  }
}

seed();
