#!/bin/bash
set -e

mkdir -p /home/runner/workspace/data/db

if ! pgrep -x mongod > /dev/null; then
  mongod --dbpath /home/runner/workspace/data/db \
    --bind_ip 127.0.0.1 \
    --port 27017 \
    --logpath /tmp/mongod.log \
    --fork
  echo "MongoDB starting..."
  sleep 3
else
  echo "MongoDB already running"
fi

node seed.js

echo "Starting backend on port 3000..."
node server.js &

echo "Starting frontend on port 5000..."
cd frontend && npm run dev
