const mongoose = require("mongoose");

const seatSchema = new mongoose.Schema({
  seat_number: Number,
  status: {
    type: String,
    enum: ["available", "booked", "not_boarded", "open"],
    default: "available"
  }
});

const trainSchema = new mongoose.Schema({
  train_name: String,
  train_number: String,
  from_station: String,
  to_station: String,
  departure_time: String,
  arrival_time: String,
  total_seats: Number,
  seats: [seatSchema]
});

module.exports = mongoose.model("Train", trainSchema);
